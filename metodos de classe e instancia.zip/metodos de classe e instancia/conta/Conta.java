/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conta;

/**
 *
 * @author LABORATORIO 01
 */
public class Conta {

    public String numeroAgencia;
    public String numeroConta;
    public double saldo;

    public static void depositar(Conta c1, double valor) {
        if (valor > 0 && c1 != null) {
            c1.saldo += valor;
            System.out.println("Deposito realizado");
            System.out.println("Novo saldo:;" + c1.saldo);
        }

    }

    public static void realizarEmprestimo(double valor, double renda, Conta c1) {
        if (valor > 0 && (renda >= 998 && renda <= 2000));
        System.out.println("Emprestimo concedido ate :" + 5000);
        System.out.println("Emprestimo realizado");
        c1.saldo = 5000;

    }

    public void realizarSaque(double valor) {
        if (valor <= 0 || valor > saldo) {
            System.out.println("Saque nao realizado!");
        } else {
            this.saldo -= valor;
            System.out.println("Saque realizado");
            System.out.println("Novo saldo" + this.saldo);
        }
    }

    public void transferir(Conta contaDestino, double valor) {
        if (this.saldo >= valor && contaDestino != null) {
            contaDestino.saldo += valor;
            this.saldo -= valor;
            System.out.println("Transferencia realizada");
            System.out.println("Novo saldo :" + this.saldo);
            System.out.println("Novo saldo C. Destino:" + contaDestino.saldo);

        }
    }

}
