/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import pacote.AlunoPacote;
import privado.AlunoPrivado;
import protegido.AlunoProtegido;
import publico.AlunoPublico;

/**
 *
 * @author LABORATORIO 01
 */
public class Main {

    public static void main(String[] args) {
        AlunoPacote aluno1 = new AlunoPacote();//PACOTE E CLASSE
        AlunoPrivado aluno2 = new AlunoPrivado();//CLASSE
        AlunoProtegido aluno3 = new AlunoProtegido();//PACOTE, CLASSE , SUBCLASSE
        AlunoPublico aluno4 = new AlunoPublico();// TODOS OS LOCAIS

        aluno1.setNome("Joao");
        aluno2.setNome("joao");
        aluno3.setNome("joao");
        aluno4.nome = "joao";

        System.out.println("Aluno pacote :" + aluno1.getNome());
        System.out.println("Aluno privado:" + aluno2.getNome());
        System.out.println("Aluno protegido:" + aluno3.getNome());
        System.out.println("Aluno publico:" + aluno4.nome);

    }

}
