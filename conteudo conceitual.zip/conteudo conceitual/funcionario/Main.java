package funcionario;

public class Main {

    public static void calcularBonificacao(Funcionario f) {
        f.bonificacao();
        if (f instanceof Gerente) {
            System.out.println("Gerente" + (f.getSalario() + f.getBonificacao()));
        } else if (f instanceof Secretaria) {
        } else {
            System.out.println("Serv.Gerais"+(f.getSalario()+f.getBonificacao()));
               
        }
    }

    public static void main(String[] args) {

        Gerente g = new Gerente();
        Secretaria s = new Secretaria();
        ServicoGerais sg = new ServicoGerais();

        s.setSalario(1000);
        sg.setSalario(1000);
        g.setSalario(1000);

    }

}
