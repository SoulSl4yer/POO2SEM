package main;

import pessoa.Aluno1;

public class Main {

    public static void main(String[] args) {
        Aluno1 p1 = new Aluno1();
        Aluno1 p2 = new Aluno1();

        p1.nome = "joão";
        p2.nome = "José";
        p1.nacionalidade = "Brasileira";
        p2.nacionalidade = "Americano";

        System.out.println(p1.nome);
        System.out.println(p2.nome);
        System.out.println(p1.nacionalidade);
        p1.andar();

    }
}
