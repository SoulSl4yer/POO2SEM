/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import produto.Chocolate;
import produto.CupNoodle;
import produto.Frutas;

/**
 *
 * @author LABORATORIO 01
 */
public class Main {

    public static void main(String[] args) {
        CupNoodle cn = new CupNoodle();
        Frutas ft = new Frutas();
        Chocolate ch = new Chocolate();

        Chocolate.setNome("Diamate Negro");
        Frutas.setNome("Maça");
        CupNoodle.setNome("Nissin");
        
        System.out.println(Chocolate.getNome());
        System.out.println(Frutas.getNome());
        System.out.println(CupNoodle.getNome());
        
    }

}
