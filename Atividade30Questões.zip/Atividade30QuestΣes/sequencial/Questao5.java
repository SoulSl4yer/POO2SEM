/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sequencial;

import java.util.Scanner;

/**
 *
 * @author Gabriel
 */
public class Questao5 {
    public static void main(String[] args) {
        int ano,meses,dias;
        int IdadeEmDias;
        
        Scanner teclado = new Scanner(System.in);
        System.out.println("Digite sua idade em anos");
        ano = teclado.nextInt();
        System.out.println("Digite a idade em meses");
        meses=teclado.nextInt();
        System.out.println("Digite a idade em dias");
        dias=teclado.nextInt();
        IdadeEmDias =ano*365 + meses * 30 + dias;
        System.out.println("Idade em dias"+IdadeEmDias);
        dias = teclado.nextInt();
    }
    
}
