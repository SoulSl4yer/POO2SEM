/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sequencial;

import java.util.Scanner;

/**
 *
 * @author Gabriel
 */
public class Questao10 {
    public static void main(String[] args) {
        double altura, base, area;
        Scanner ler = new Scanner(System.in);
        System.out.println("Digite a base do retangulo");
        base = ler.nextDouble();
        System.out.println("Digite a altura do retangulo");
        altura = ler.nextDouble();
        area = (base * altura);
        System.out.println("A area do retangulo é:" + area);
    }
    
}
