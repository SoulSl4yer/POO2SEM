/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sequencial;

import java.util.Scanner;

/**
 *
 * @author Gabriel
 */
public class Questao8 {

    public static void main(String[] args) {
        double fabrica, distribuidor, impostos, consumidor;
        Scanner ler = new Scanner(System.in);
        System.out.println("Digite o custo de fabrico do veiculo");
        fabrica = ler.nextDouble();
        distribuidor = (fabrica * 0.28) + fabrica;
        consumidor = (distribuidor * 0.45) + distribuidor;
        System.out.println("O valor do automovel para o consumidor é:" + consumidor);

    }

}
