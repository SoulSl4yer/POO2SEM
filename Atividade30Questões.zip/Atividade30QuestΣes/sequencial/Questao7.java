/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sequencial;

import java.util.Scanner;

/**
 *
 * @author Gabriel
 */
public class Questao7 {

    public static void main(String[] args) {
        String funcionario;
        double salario, acrescimo, NovoSalario;

        Scanner ler = new Scanner(System.in);
        System.out.println("Nome do funcionario");
        funcionario = ler.next();
        System.out.println("Salario");
        salario = ler.nextDouble();
        System.out.println("Acrescimo");
        acrescimo = ler.nextDouble();
        NovoSalario = (salario * (acrescimo / 100) + 1);
        System.out.println(funcionario + "receberá" + NovoSalario);

    }

}
