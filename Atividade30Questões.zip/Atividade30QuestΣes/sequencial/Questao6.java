/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sequencial;

import java.util.Scanner;

/**
 *
 * @author Gabriel
 */
public class Questao6 {

    public static void main(String[] args) {
        int nulos, brancos, validos, eleitores = 5000;

        double PorcValidos , PorcNulos , PorcBrancos ;

        Scanner ler = new Scanner(System.in);
        System.out.println("Digite a quantidade de votos brancos");
        brancos = ler.nextInt();
        System.out.println("Digite  quantidade de votos nulos");
        nulos = ler.nextInt();
        System.out.println("Digite a quantidade de votos validos");
        validos = ler.nextInt();

        PorcNulos = (100 * brancos) / eleitores;
        PorcValidos = (100 * validos) / eleitores;
        PorcBrancos = (100 * validos) / eleitores;

        System.out.println("A porcentagem de votos brancos é:" + PorcBrancos);
        System.out.println("A pocentagem de votos validos é:" + PorcValidos);
        System.out.println("A porcentagem de votos nulos é:" + PorcNulos);

    }

}
