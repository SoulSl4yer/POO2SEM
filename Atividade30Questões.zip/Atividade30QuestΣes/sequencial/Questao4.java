/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sequencial;

import java.util.Scanner;

/**
 *
 * @author Gabriel
 */
public class Questao4 {public static void main(String [] args ) 
{ 
int x; 
Scanner numero = new Scanner( System.in ); 
System.out.print( "Digite um valor inteiro: " ); 
x = numero.nextInt( ); 
System.out.print( "Antecessor: " ); 
System.out.println( x-1 ); 
System.out.print( "Sucessor: " ); 
System.out.println( x+1 ); 
} 
} 

   

