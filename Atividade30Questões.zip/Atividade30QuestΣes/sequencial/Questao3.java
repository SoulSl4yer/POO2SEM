/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sequencial;

/**
 *
 * @author Gabriel
 */
public class Questao3 {

    public static void main(String[] args) {

        int A = 10;
        int B = 20;
        int C=0;
        C=A;
        A=B;
        B=C;
                
        System.out.println(A);
        System.out.println(B);
       
    
    }
}
