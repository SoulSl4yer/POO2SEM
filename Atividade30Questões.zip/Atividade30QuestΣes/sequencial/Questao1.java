/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sequencial;

import java.util.Scanner;

/**
 *
 * @author Gabriel
 */
public class Questao1 {

    public static double notas(double n1, double n2, double n3) {
        return (n1 + n2 + n3) / 3;

    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("digite n1");
        double n1 = sc.nextDouble();
        System.out.println("digite n2");
        double n2 = sc.nextDouble();
        System.out.println("digite n3");
        double n3 = sc.nextDouble();
        System.out.println(notas(n1, n2, n3));

    }

}
