/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sequencial;

import java.util.Scanner;

/**
 *
 * @author Gabriel
 */
public class Questao2 {

    public static double triangulo(double base, double altura) {
        return (base*altura)/3;

    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        System.out.println("Digite a Base");
        double base = teclado.nextDouble();
        System.out.println("Digite a Altura");
        double altura = teclado.nextDouble();
        System.out.println(triangulo(base , altura));
        

    }

}
