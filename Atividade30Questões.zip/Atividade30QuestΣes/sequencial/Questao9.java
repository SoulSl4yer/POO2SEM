/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sequencial;

import java.util.Scanner;

/**
 *
 * @author Gabriel
 */
public class Questao9 {

    public static void main(String[] args) {
        double n1, n2, n3, n4, n5;
        Scanner ler = new Scanner(System.in);
        System.out.println("Quantos carros o funcionario vendeu?");
        n1 = ler.nextDouble();
        System.out.println("Qual o valor total das vendas do funcionario?");
        n2 = ler.nextDouble();
        System.out.println("Qual o salario fixo do funcionario?");
        n3 = ler.nextDouble();
        System.out.println("Quanto de comissao é recebido por carro vendido?");
        n4 = ler.nextDouble();
        n5 = (n4 + n3 + n2 + n1 * 0.03);
        System.out.println("O salario final do funcionario é:" + n5);

    }
}
