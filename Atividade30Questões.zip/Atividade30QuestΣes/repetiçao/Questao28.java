/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repetiçao;

import java.util.Scanner;

/**
 *
 * @author Gabriel
 */
public class Questao28 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        int n;
        System.out.println("Digite um numero para a tabuada");
        n = ler.nextInt();
        for (int i = 0; i <=10; i++) {
            System.out.println(n+"x"+ i + "=" + (i * n)
        
    

);
        }
        
    }
    
}
