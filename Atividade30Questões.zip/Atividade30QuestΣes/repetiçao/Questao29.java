/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repetiçao;

import java.util.Scanner;

/**
 *
 * @author Gabriel
 */
public class Questao29 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        int soma=0,n=0;
        for(int i=0;i<=9;i++){
            System.out.println("Informe o numero");
            n=ler.nextInt();
          soma=soma+n;  
    }
        System.out.println("A soma dos 10 numeros é:"+soma);
    }
}
