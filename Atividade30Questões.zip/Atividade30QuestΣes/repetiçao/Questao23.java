/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repetiçao;

import java.util.Scanner;

/**
 *
 * @author Gabriel
 */
public class Questao23 {

    public static void main(String[] args) {
        double n1, n2, media;
        Scanner ler = new Scanner(System.in);
        System.out.println("Digite sua nota");
        n1 = ler.nextDouble();
        while (n1 < 0 || n1 > 10) {
            System.out.println("Digite novamente");
            n1 = ler.nextDouble();
            System.out.println();
        }

        System.out.println("Digite sua nota ");
        n2 = ler.nextDouble();
        while (n2 < 0 || n2 > 10) {
            System.out.println("Digite novamente");
            n2 = ler.nextDouble();
            System.out.println();

        }
        media = (n1+n2)/2;
        System.out.println("A sua media final é :"+media);

    }

}
