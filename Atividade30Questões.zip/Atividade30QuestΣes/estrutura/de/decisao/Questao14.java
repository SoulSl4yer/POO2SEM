/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estrutura.de.decisao;

import java.util.Scanner;

/**
 *
 * @author Gabriel
 */
public class Questao14 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        double n1;
        System.out.println("Digite sua nota");
        n1 = ler.nextDouble();
        if (n1 >= 7) {
            System.out.println("Aprovado");
        } else if (n1 >= 4 && n1 < 7) {
            System.out.println("Recuperaçao");

        }
        if (n1 < 4) {
            System.out.println("Reprovado");
        }
    }
}
