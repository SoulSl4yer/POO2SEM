/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estrutura.de.decisao;

import java.util.Scanner;

/**
 *
 * @author Gabriel
 */
public class Questao16 {
    public static void main(String[] args) {
        int n1,n2;
        Scanner ler = new Scanner(System.in);
        System.out.println("Digite um numero");
        n1 = ler.nextInt();
        System.out.println("Digite mais um numero");
        n2 = ler.nextInt();
        if(n1 > n2){
            System.out.println("O maior é o valor "+n1);
        }if(n2>n1){
            System.out.println("O maior é o valor "+n2);
        }
    }
    
}
