/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estrutura.de.decisao;

import java.util.Scanner;

/**
 *
 * @author Gabriel
 */
public class Questao12 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        int n1;
        System.out.println("Digite um numero");
        n1 = ler.nextInt();
        if (n1 >= 0) {
            System.out.println("é positivo");

        } else if (n1 < 0) {
            System.out.println("é negativo");
        }
    }

}
