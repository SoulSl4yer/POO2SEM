/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estrutura.de.decisao;

import java.util.Scanner;

/**
 *
 * @author Gabriel
 */
public class Questao19 {

    public static void main(String[] args) {
        int nconta;
        double debito, saldoAt, credito, saldo;
        Scanner ler = new Scanner(System.in);
        System.out.println("Digite o numero da conta");
        nconta = ler.nextInt();
        System.out.println("Digite seu credito");
        credito = ler.nextDouble();
        System.out.println("Digite seu saldo");
        saldo = ler.nextDouble();
        System.out.println("Digite seu debito");
        debito = ler.nextDouble();
        saldoAt = saldo - debito + credito;
        if (saldoAt > 0) {
            System.out.println("Saldo positivo");
        }
        if (saldoAt < 0) {
            System.out.println("Saldo negativo");
        }

    }

}
