/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estrutura.de.decisao;

import java.util.Scanner;

/**
 *
 * @author Gabriel
 */
public class Questao20 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);

        double salario, vendas, a, b, c;

        System.out.println("Digite seu salario");
        salario = ler.nextDouble();
        System.out.println("Digite o total de vendas");
        vendas = ler.nextDouble();
        if (vendas > 1500) {
            System.out.println(a = vendas * 0.05);
            System.out.println(b = salario + a);
            System.out.println("Salario final:" + b);

        } else if (vendas < 1500) {
            System.out.println(a = vendas * 0.03);
            System.out.println(b = salario + a);
            System.out.println("Salario final:" + b);
        }
    }

}
