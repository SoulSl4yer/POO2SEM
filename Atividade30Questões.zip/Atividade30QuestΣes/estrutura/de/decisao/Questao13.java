/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estrutura.de.decisao;

import java.util.Scanner;

/**
 *
 * @author Gabriel
 */
public class Questao13 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        double maça;

        System.out.println("Quantas maças voce deseja ?:");
        maça = ler.nextDouble();
        if(maça<12){
            System.out.println("O valor das maças é:"+maça*1.30);
            maça=ler.nextDouble();
        }if(maça>=12){
            System.out.println("O valor das maças é:"+maça*1.00);
            maça=ler.nextDouble();
            
        }
        

    }

}
