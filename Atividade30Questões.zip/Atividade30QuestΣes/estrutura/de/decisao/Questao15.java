/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estrutura.de.decisao;

import java.util.Scanner;

/**
 *
 * @author Gabriel
 */
public class Questao15 {

    public static void main(String[] args) {
        double idade, dnascimento, anoAtual;
        Scanner ler = new Scanner(System.in);
        System.out.println("Digite sua data de nascimento");
        dnascimento = ler.nextDouble();
        System.out.println("Digite o ano atual");
        anoAtual = ler.nextDouble();
        idade = anoAtual-dnascimento;

        if (idade >=16) {
            System.out.println("Pode votar");
        }if(idade <16){
            System.out.println("Nao pode votar");
        }

    }

}
