/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estrutura.de.decisao;

import java.util.Scanner;

/**
 *
 * @author Gabriel
 */
public class Questao11 {

    public static void main(String[] args) {
        int n1;
        Scanner ler = new Scanner(System.in);
        System.out.println("Digite n1");
        n1 = ler.nextInt();
        if (n1 > 10) {
            System.out.println("E maior que 10");
        } else if (n1 < 10) {
            System.out.println("E menor que 10");
        }
    }

}
