/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loja;

/**
 *
 * @author Gabriel
 */
public class Main {

    public static void main(String[] args) {
        Frentista ft = new Frentista();
        Gerente gt = new Gerente();
        AtdConveniencia ac = new AtdConveniencia();
        
        ac.nomeFuncionario();
        System.out.println("Idade do trabalhador:"+ac.idade(2019, 1995));
        System.out.println("Horas de trabalho por dia:"+ac.tempo(8));

        gt.nomeFuncionario();
        System.out.println("Idade do trabalhador:" + gt.idade(2019,1980 ));
        System.out.println("Horas de trabalho por dia:" + gt.tempo(8));

        ft.nomeFuncionario();
        System.out.println("Idade do trabalhador:" + ft.idade(2019, 2000));
        System.out.println("Horas de trabalho por dia:" + ft.tempo(8));

    }

}
