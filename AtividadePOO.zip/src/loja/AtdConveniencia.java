/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loja;

/**
 *
 * @author Gabriel
 */
public class AtdConveniencia extends Funcionario {

    @Override
    public void nomeFuncionario() {
        System.out.println("Ana");

    }

}
