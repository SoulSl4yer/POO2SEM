/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loja;

/**
 *
 * @author Gabriel
 */
public class Funcionario {

    public void nomeFuncionario() {
        System.out.println();

    }

    public int idade(int anoNascimento, int anoAtual) {
        return anoNascimento - anoAtual;

    }

    public double tempo(double horasDeTrab) {
        return horasDeTrab;
    }

}
