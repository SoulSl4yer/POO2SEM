/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoa;

/**
 *
 * @author Gabriel
 */
public class Pessoa {

    private String nome;

    public void nomePessoa() {

    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int idade(int anoNascimento, int anoAtual) {
        return anoNascimento - anoAtual;
    }
    
    public String cpf(String cpf){
     return cpf;   
    
    }
    
    public double salario(double salario){
    
    return salario;
    }

}
