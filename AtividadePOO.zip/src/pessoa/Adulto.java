/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoa;

/**
 *
 * @author Gabriel
 */
public class Adulto extends Pessoa {
    @Override
    public void nomePessoa() {

        System.out.println("Joice");
    }
}
