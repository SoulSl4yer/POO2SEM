/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pessoa;

/**
 *
 * @author Gabriel
 */
public class Main {

    public static void main(String[] args) {
     
        Adulto ad = new Adulto();
        Criança cr = new Criança();
        Idoso id = new Idoso();
        
        ad.nomePessoa();
        System.out.println("Idade:"+ad.idade(2019,1980));
        System.out.println("Salário:"+ad.salario(998));
        System.out.println("cpf:"+ad.cpf("333222999-88"));
        
        
        cr.nomePessoa();
        System.out.println("Idade:"+cr.idade(2019,2010));
        System.out.println("Salario:"+cr.salario(0));
        System.out.println("Cpf:"+cr.cpf("333222999-99"));
        
        id.nomePessoa();
        System.out.println("Idade:"+id.idade(2019,1950));
        System.out.println("Salario:"+id.salario(4999));
        System.out.println("cpf:"+id.cpf("223222999-99"));
        
    }

}
