/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zoologico;

/**
 *
 * @author Gabriel
 */
public class Main {

    public static void main(String[] args) {

        Cachorro ch = new Cachorro();
        Gato gt = new Gato();
        Papagaio pa = new Papagaio();
        
         gt.barulhoAnimal();
         gt.açaoAnimal(2, "Gatos");
         ch.barulhoAnimal();
         ch.açaoAnimal(3, "Cachorros");
         pa.barulhoAnimal();
         pa.açaoAnimal(1, "Papagaio");
    }

}
