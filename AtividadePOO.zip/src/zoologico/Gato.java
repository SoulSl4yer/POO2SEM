/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zoologico;

/**
 *
 * @author Gabriel
 */
public class Gato extends Animal {

    @Override
    public void barulhoAnimal() {
        System.out.println("Está miando!");
    }
    
    public String açaoAnimal(String nomeAnimal) {
        
        System.out.println("qual o nome do seu"+nomeAnimal);
        return nomeAnimal;
        
        
    }
    public int açaoAnimal(int qtdAnimais,String nomeAnimal){
        System.out.println("Quantos"+nomeAnimal+"você tem?" +qtdAnimais);
        return qtdAnimais;
    }

}
